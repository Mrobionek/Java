public class Main {
    public static void main(String[] args) {

       Arithmetic calculator = new Arithmetic(5, 4);

        calculator.summ();
        calculator.function();
        calculator.min();
        calculator.max();

        calculator.print("Результат: ");





    }
}
